package com.first.visualp2;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class F1rstVisualP2 implements ClientModInitializer {

    public static boolean particlesEnabled = true;
    public static boolean trailsEnabled = true;
    public static boolean hudEnabled = true;
    public static boolean optimizedMode = false;

    private static KeyBinding openMenuKey;

    @Override
    public void onInitializeClient() {
        System.out.println("F1rstVisualP2 loaded!");

        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
            "key.visualp2.openmenu",
            InputUtil.Type.KEYSYM,
            GLFW.GLFW_KEY_R,
            "category.visualp2"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (client.player != null) {
                if (particlesEnabled) VisualEffects.spawnPlayerParticles(client, optimizedMode);
                if (trailsEnabled) VisualEffects.spawnPlayerTrail(client, optimizedMode);

                while (openMenuKey.wasPressed()) {
                    client.setScreen(new ModMenuScreen());
                }
            }
        });
    }

    public static void toggleParticles() { particlesEnabled = !particlesEnabled; }
    public static void toggleTrails() { trailsEnabled = !trailsEnabled; }
    public static void toggleHUD() { hudEnabled = !hudEnabled; }
    public static void toggleOptimizedMode() { optimizedMode = !optimizedMode; }
}
