package com.first.visualp2;

import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.text.Text;

public class ModMenuScreen extends Screen {

    protected ModMenuScreen() {
        super(Text.literal("F1rstVisualP2 Menu"));
    }

    @Override
    protected void init() {
        int y = this.height / 4;

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Toggle Particles"), b -> F1rstVisualP2.toggleParticles())
            .dimensions(this.width / 2 - 100, y, 200, 20).build());

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Toggle Trails"), b -> F1rstVisualP2.toggleTrails())
            .dimensions(this.width / 2 - 100, y + 25, 200, 20).build());

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Toggle HUD"), b -> F1rstVisualP2.toggleHUD())
            .dimensions(this.width / 2 - 100, y + 50, 200, 20).build());

        this.addDrawableChild(ButtonWidget.builder(Text.literal("Optimized Mode"), b -> F1rstVisualP2.toggleOptimizedMode())
            .dimensions(this.width / 2 - 100, y + 75, 200, 20).build());
    }

    @Override
    public void render(MatrixStack matrices, int mouseX, int mouseY, float delta) {
        this.renderBackground(matrices);
        drawCenteredText(matrices, this.textRenderer, "F1rstVisualP2 Settings", this.width / 2, 20, 0xFFFFFF);
        super.render(matrices, mouseX, mouseY, delta);
    }
}
