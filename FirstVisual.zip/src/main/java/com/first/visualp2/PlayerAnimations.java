package com.first.visualp2;

import net.minecraft.client.network.ClientPlayerEntity;

public class PlayerAnimations {

    public static void applyAnimations(ClientPlayerEntity player) {
        if (player == null) return;

        float motion = (float)Math.sqrt(player.getVelocity().x*player.getVelocity().x + player.getVelocity().z*player.getVelocity().z);
        player.pitch = -motion * 5f;
    }
}
