package com.first.visualp2;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.particle.ParticleTypes;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;

public class VisualEffects {

    public static void spawnPlayerParticles(MinecraftClient client, boolean optimized) {
        PlayerEntity player = client.player;
        if (player == null) return;
        Vec3d pos = player.getPos();

        int count = optimized ? 2 : 10;
        for (int i = 0; i < count; i++) {
            client.world.addParticle(
                ParticleTypes.HAPPY_VILLAGER,
                pos.x + (Math.random() - 0.5),
                pos.y + 1,
                pos.z + (Math.random() - 0.5),
                0, 0.05, 0
            );
        }
    }

    public static void spawnPlayerTrail(MinecraftClient client, boolean optimized) {
        PlayerEntity player = client.player;
        if (player == null) return;
        Vec3d pos = player.getPos();

        int count = optimized ? 1 : 5;
        for (int i = 0; i < count; i++) {
            client.world.addParticle(
                ParticleTypes.CRIT,
                pos.x,
                pos.y,
                pos.z,
                0, 0.01, 0
            );
        }
    }
}
